.. automodule:: scipy.linalg.cython_blas
   :no-members:
   :no-inherited-members:
   :no-special-members:
