.. automodule:: scipy.misc
   :no-members:
   :no-inherited-members:
   :no-special-members:
