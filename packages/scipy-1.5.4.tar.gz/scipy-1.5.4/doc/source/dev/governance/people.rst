:orphan:

.. _governance-people:

Current steering council and institutional partners
===================================================

Benevolent Dictator for Life
----------------------------

Pauli Virtanen is the Benevolent Dictator for Life (BDFL)


Steering Council
----------------

* Anne Archibald
* Andrew Nelson
* Charles Harris
* CJ Carey
* Denis Laxalde
* Eric Larson
* Eric Moore
* Eric Quintero
* Evgeni Burovski
* Jaime Fernández del Río
* Josef Perktold
* Josh Wilson
* Matthew Brett
* Nikolay Mayorov
* Pauli Virtanen
* Ralf Gommers (Chair)
* Tyler Reddy
* Warren Weckesser


Release Manager
---------------

Ralf Gommers is the release manager for the 1.0 release


Institutional Partners
----------------------

None currently


Document history
----------------

https://github.com/scipy/scipy/commits/master/doc/source/dev/governance/people.rst
