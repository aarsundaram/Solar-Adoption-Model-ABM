GML
===
.. automodule:: networkx.readwrite.gml
.. autosummary::
   :toctree: generated/

   read_gml
   write_gml
   parse_gml
   generate_gml
   literal_destringizer
   literal_stringizer
