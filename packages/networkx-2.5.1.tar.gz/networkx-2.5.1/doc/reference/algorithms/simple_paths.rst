************
Simple Paths
************

.. automodule:: networkx.algorithms.simple_paths
.. autosummary::
   :toctree: generated/

   all_simple_paths
   all_simple_edge_paths
   is_simple_path
   shortest_simple_paths
