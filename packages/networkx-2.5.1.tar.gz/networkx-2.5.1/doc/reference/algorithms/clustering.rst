**********
Clustering
**********

.. automodule:: networkx.algorithms.cluster
.. autosummary::
   :toctree: generated/

   triangles
   transitivity
   clustering
   average_clustering
   square_clustering
   generalized_degree
