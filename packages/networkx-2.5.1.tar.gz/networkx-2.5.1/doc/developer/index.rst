.. _developer:

Developer Guide
***************

.. toctree::
   :maxdepth: 2

   code_of_conduct
   values
   contribute
   core_developer
   gitwash/index
   release
   deprecations
   roadmap
   nxeps/index
